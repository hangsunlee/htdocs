<!DOCTYPE html>
<?php
//    $sql = 'select * from member';
//    $sql->prepare();
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <style>
            tr {background: #ccffff;}
            th {border: 1px solid black;}
        </style>
    </head>
    <body>
        <table>
            <tr>
                <th>id</th>
                <th>password</th>
                <th>name</th>
                <th>phoneNumber</th>
            </tr>
        <?php
        // put your code here
        ?>
            
        <?php
        
        ?>
        </table>
    </body>
</html>

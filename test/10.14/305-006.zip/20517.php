<?php
try{
        $pdo = new pdo('mysql:host=localhost;dbname=sdhs;charset=utf8','root',''); 
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
        print 'nice';
}catch(Exception $e) {
        echo $e->getMessage();
        return false;
}
?>
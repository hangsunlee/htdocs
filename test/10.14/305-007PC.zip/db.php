<? php
    try{
        $pdo = new PDO("mysql:host=127.0.0.1; dbname=user", '', '');
        $pdo -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo -> prepare("select from user");
        $pdo -> execute();
        echo "접속성공";
    }
    catch(PDOException $e){echo "접속실패";}
?>
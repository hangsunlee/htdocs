<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>20507 김형준 수행평가</title>
    </head>
    <body>
        <?php
        $db_host: "localhost";
        $db_name: "kcc";
        $db_type: "mysql";
        $db_psn:"type:host:$db_host,name:$db_name,charset:utf8";
        
        try {
            pdo()
            pdo->PDO::ATTR_ERRMODE,PDO::ATTR_
            pdo->PDO::ATTR_EMULATE_PREPARES,prepares:false;
            print"connect";
        } catch (PDOException $Exception) {
            print"오류".PDOException
        }
        ?>
    </body>
</html>
